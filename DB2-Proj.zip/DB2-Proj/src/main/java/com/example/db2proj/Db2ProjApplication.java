package com.example.db2proj;

import Fachlogic.EScooter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Db2ProjApplication {

    public static void main(String[] args) {
        SpringApplication.run(Db2ProjApplication.class, args);
    }

}
