package App;

import Fachlogic.*;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controller {
    @PersistenceUnit
    private static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("PersistenceUnit");
    @PersistenceContext
    static EntityManager entityManager = entityManagerFactory.createEntityManager();

    public Controller() {

    }

    public void AdminController(EntityManager entityManager) {
        Scanner scanner = new Scanner(System.in);
        int input = 0;
    }

    public void UserController(EntityManager entityManager) {
        Scanner scanner = new Scanner(System.in);
        int input = 0;
    }

    public void InitialDate() {
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        Adress adress1 = new Adress("kampstr",1,44136,"dortmund");
        Adress adress2 = new Adress("kampstr",1, 44136,"dortmund");

        Adress stationAdress = new Adress("kampstr",1,44133,"dortmund");


        List moAdresses = new ArrayList();
        moAdresses.add(adress2);

        List basharAdresses = new ArrayList();
        basharAdresses.add(adress1);

        String phone1 = "123456789";
        String phone2 = "987654321";

        List basharPhones = new ArrayList<>();
        basharPhones.add(phone1);

        List moPhones = new ArrayList<>();
        moPhones.add(phone2);


        User bashar = new User("bashar","alzamel","bashar@fhdortmund.de",basharPhones, basharAdresses, 12,null,null);
        User mo = new User("Mo","algoutani","mo@fhdoretmund.de",moPhones, moAdresses, 200,null,null);
        bashar.toString();


        EScooter eScooter = new EScooter("BMW", true, 20);
        Station station1 = new Station("city Station", 100, stationAdress);





        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
