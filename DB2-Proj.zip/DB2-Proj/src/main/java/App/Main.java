package App;

import Fachlogic.Adress;
import Fachlogic.User;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Adress adress1 = new Adress("kampstr",1,44133,"dortmund");
        Adress adress2 = new Adress("kampstr",1,44133,"dortmund");

        Adress stationAdress = new Adress("kampstr",1,44133,"dortmund");


        List moAdresses = new ArrayList();
        moAdresses.add(adress2);

        List basharAdresses = new ArrayList();
        basharAdresses.add(adress1);

        String phone1 = "123456789";
        String phone2 = "987654321";

        List basharPhones = new ArrayList<>();
        basharPhones.add(phone1);

        List moPhones = new ArrayList<>();
        moPhones.add(phone2);


        User bashar = new User("bashar","alzamel","bashar@fhdortmund.de",basharPhones, basharAdresses, 12,null,null);
        User mo = new User("Mo","algoutani","mo@fhdoretmund.de",moPhones, moAdresses, 200,null,null);

        System.out.println(bashar);
        System.out.println(mo);

    }
}
