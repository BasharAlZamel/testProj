package Fachlogic;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Adress")
public class Adress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long adressID;
    @Column(length = 10, nullable = false)
    private String street;

    @Column(length = 4, nullable = false)
    private int houseNumber;

    @Column(length = 5, nullable = false)
    private int PLZ;

    @Column(length = 50, nullable = false)
    private String city;

    @ManyToMany(mappedBy = "adresss")
    private List<Person> persons = new ArrayList<>();

    @OneToOne(mappedBy = "adresse")
    private Station station;

    public Adress(String street, int houseNumber,  int PLZ, String city) {
        this.street = street;
        this.houseNumber = houseNumber;
        this.PLZ = PLZ;
        this.city = city;
    }

    public Adress() {

    }

    public String getStraße() {
        return street;
    }

    public void setStraße(String street) {
        this.street = street;
    }

    public void setStadt(String city) {
        this.city = city;
    }

    public void setHausnummer(int houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getStadt() {
        return city;
    }

    public int getHausnummer() {
        return houseNumber;
    }

    public int getPLZ() {
        return PLZ;
    }

    public void setPLZ(int PLZ) {
        this.PLZ = PLZ;
    }

    @Override
    public String toString() {
        return "Adress{" +
                "adressID=" + adressID +
                ", street='" + street + '\'' +
                ", houseNumber=" + houseNumber +
                ", PLZ=" + PLZ +
                ", city='" + city + '\'' +
                '}';
    }
}

