package Fachlogic;

import jakarta.persistence.*;

@Entity
@Table(name = "Payment")
public class Payment {
    @Id
    @GeneratedValue
    private int paymentId;

    @Column(length = 10, nullable = false)
    private double costs;

    @Column(length = 10, nullable = false)
    private int bookingPeriod;

    @Column(nullable = false)
    private boolean paymentCheck;

    public Payment(double costs, int bookingPeriod, boolean paymentCheck) {
        this.costs = costs;
        this.bookingPeriod = bookingPeriod;
        this.paymentCheck = paymentCheck;
    }

    public Payment() {

    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public double getCosts() {
        return costs;
    }

    public void setCosts(double costs) {
        this.costs = costs;
    }

    public int getBookingPeriod() {
        return bookingPeriod;
    }

    public void setBookingPeriod(int bookingPeriod) {
        this.bookingPeriod = bookingPeriod;
    }

    public boolean isPaymentCheck() {
        return paymentCheck;
    }

    public void setPaymentCheck(boolean paymentCheck) {
        this.paymentCheck = paymentCheck;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "paymentId=" + paymentId +
                ", costs=" + costs +
                ", bookingPeriod=" + bookingPeriod +
                ", paymentCheck=" + paymentCheck +
                '}';
    }
}
