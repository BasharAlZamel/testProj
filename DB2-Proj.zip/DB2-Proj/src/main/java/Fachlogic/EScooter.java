package Fachlogic;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ESccoter")
public class EScooter {
    @Id
    @GeneratedValue
    private int escooterId;
    @Column(length = 10)
    private String brand;
    @Column (nullable = false)
    private boolean status;
    @Column (nullable = false)
    private int batteryCapacity;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "escooter_station",
            joinColumns = @JoinColumn(name = "escooter_id"),
            inverseJoinColumns = @JoinColumn(name = "station_id")
    )
    private List<Station> stations = new ArrayList<>();

    public EScooter(String brand, boolean status, int batteryCapacity) {
        this.brand = brand;
        this.status = status;
        this.batteryCapacity = batteryCapacity;
    }

    public EScooter() {

    }

    public int getEscooterId() {
        return escooterId;
    }

    public void setEscooterId(int escooterId) {
        this.escooterId = escooterId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getBatteryCapacity() {
        return batteryCapacity;
    }

    public void setBatteryCapacity(int batteryCapacity) {
        this.batteryCapacity = batteryCapacity;
    }

    public List<Station> getStations() {
        return stations;
    }

    public void setStationen(List<Station> stations) {
        this.stations = stations;
    }

    @Override
    public String toString() {
        return "EScooter{" +
                "escooterId=" + escooterId +
                ", brand='" + brand + '\'' +
                ", status=" + status +
                ", batteryCapacity=" + batteryCapacity +
                ", stations=" + stations +
                '}';
    }
}
