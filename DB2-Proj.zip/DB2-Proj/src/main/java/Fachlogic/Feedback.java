package Fachlogic;

import jakarta.persistence.*;

@Entity
@Table(name = "Feedbach")
public class Feedback {
    @Id
    @GeneratedValue
    private int feedbackId;

    @Column(length = 1000)
    private String feedbackText;

    public Feedback(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    public Feedback() {

    }

    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "feedbackId=" + feedbackId +
                ", feedbackText='" + feedbackText + '\'' +
                '}';
    }
}
