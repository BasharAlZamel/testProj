package Fachlogic;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "Reservation")
public class Reservation {
    @Id
    @GeneratedValue
    private int reservationId;

    @Column (nullable = false)
    private Station pickUpStation;
    @Column (nullable = false)
    private Station returnStation;

    @Column (nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime startTime;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime endTime;

    public Reservation(int reservationId, Station pickUpStation, Station returnStation, LocalDateTime startTime, LocalDateTime endTime) {
        this.reservationId = reservationId;
        this.pickUpStation = pickUpStation;
        this.returnStation = returnStation;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Reservation() {

    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public Station getPickUpStation() {
        return pickUpStation;
    }

    public void setPickUpStation(Station pickUpStation) {
        this.pickUpStation = pickUpStation;
    }

    public Station getReturnStation() {
        return returnStation;
    }

    public void setReturnStation(Station returnStation) {
        this.returnStation = returnStation;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", pickUpStation=" + pickUpStation +
                ", returnStation=" + returnStation +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
