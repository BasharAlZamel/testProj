package Fachlogic;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Inheritance (strategy = InheritanceType.JOINED)
@Table (name = "User")
public class User extends Person{

    @Column(length = 10, nullable = false)
    private double credit;

    @OneToMany(mappedBy = "id" , fetch = FetchType.LAZY )
    private List<Reservation> reservation = new ArrayList<>();

    @OneToMany(mappedBy = "id" , fetch = FetchType.LAZY )
    private List<Feedback> feedback = new ArrayList<>();

    public User(String firstName, String lastNname, String email, List<String> phone, List<Adress> adress, double credit, List<Feedback> feedbackList, List<Reservation> reservationList) {
        super(firstName, lastNname, email, phone, adress);
        this.credit = credit;
        this.feedback = feedbackList;
        this.reservation = reservationList;
    }

    public User(double credit) {
        this.credit = credit;
    }

    public User() {
        super();
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    @Override
    public String toString() {
        return super.toString() + "credit=" + credit +
                '}';
    }
}
