package Fachlogic;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table (name = "Station")
@Embeddable
public class Station {
    @Id
    @GeneratedValue
    private int stationId;

    @Column(length = 30 , nullable = false)
    private String name;

    @Column (length = 4 , nullable = false)
    private int capacity;

    @OneToOne
    @JoinColumn(name = "adressId")
    private Adress adress;

    @ManyToMany(mappedBy = "stationen")
    private List<EScooter> escooter = new ArrayList<>();

    public Station(String name, int capacity, Adress adress) {
        this.name = name;
        this.capacity = capacity;
        this.adress = adress;
    }

    public Station() {

    }

    public int getStationId() {
        return stationId;
    }

    public void setStationId(int stationId) {
        this.stationId = stationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Adress getAdress() {
        return adress;
    }

    public void setAdress(Adress adress) {
        this.adress = adress;
    }

    @Override
    public String toString() {
        return "Station{" +
                "stationId=" + stationId +
                ", name='" + name + '\'' +
                ", capacity=" + capacity +
                ", adress=" + adress +
                '}';
    }
}
