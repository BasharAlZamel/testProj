package Fachlogic;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Inheritance (strategy = InheritanceType.TABLE_PER_CLASS)
@Table (name = "Person")
public abstract class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int personId;

    @Column (length = 30 , nullable = false)
    private String firstName;

    @Column (length = 30 , nullable = false)
    private String LastNname;

    @Column (length = 30 , nullable = false)
    private String email;

    @ElementCollection
    private List<String> phone;

    @OneToMany
    @JoinColumn (name = "tgid" , referencedColumnName = "id" , nullable = true)
    private List<Adress> adress = new ArrayList<>();

    public Person(String firstName, String lastNname, String email, List<String> phone, List<Adress> adress) {
        this.firstName = firstName;
        this.LastNname = lastNname;
        this.email = email;
        this.phone = phone;
        this.adress = adress;
    }

    public Person() {

    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastNname() {
        return LastNname;
    }

    public void setLastNname(String lastNname) {
        LastNname = lastNname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getPhone() {
        return phone;
    }

    public void setPhone(List<String> phone) {
        this.phone = phone;
    }

    public List<Adress> getAdress() {
        return adress;
    }

    public void setAdress(List<Adress> adress) {
        this.adress = adress;
    }

    @Override
    public String toString() {
        return "Person{" +
                "personId=" + personId +
                ", firstName='" + firstName + '\'' +
                ", LastNname='" + LastNname + '\'' +
                ", email='" + email + '\'' +
                ", phone=" + phone +
                ", adresss=" + adress +
                '}';
    }
}
