package Fachlogic;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Employee")
public class Employee extends Person{
    @Column(length = 10 , nullable = false)
    private String position;

    public Employee(String firstName, String lastNname, String email, List<String> phone, List<Adress> adress, String position) {
        super(firstName, lastNname, email, phone, adress);
        this.position = position;
    }

    public Employee() {
        super();
    }

    public Employee(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return super.toString() + "position='" + position + '\'' + '}';
    }
}
