package com.example.db2proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Db2ProjApplicationTests {

    @Test
    void contextLoads() {
    }

}
